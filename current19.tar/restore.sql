--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.7
-- Dumped by pg_dump version 9.5.7

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

DROP INDEX public.unique_schema_migrations;
DROP INDEX public.index_users_on_username;
DROP INDEX public.index_premix_ingredients_on_ingredient_id_and_formula_id;
DROP INDEX public.index_nutrients_on_user_id_and_name;
DROP INDEX public.index_ingredients_on_user_id_and_name;
DROP INDEX public.index_ingredient_compositions_on_ingredient_id_and_nutrient_id;
DROP INDEX public.index_formula_nutrients_on_nutrient_id_and_formula_id;
DROP INDEX public.index_formula_ingredients_on_ingredient_id_and_formula_id;
DROP INDEX public.index_formula_ingredients_histories_on_ingredient_id;
DROP INDEX public.index_formula_ingredients_histories_on_formula_id;
DROP INDEX public.by_ing_id_for_id_log_at;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_pkey;
ALTER TABLE ONLY public.premix_ingredients DROP CONSTRAINT premix_ingredients_pkey;
ALTER TABLE ONLY public.nutrients DROP CONSTRAINT nutrients_pkey;
ALTER TABLE ONLY public.ingredients DROP CONSTRAINT ingredients_pkey;
ALTER TABLE ONLY public.ingredient_compositions DROP CONSTRAINT ingredient_compositions_pkey;
ALTER TABLE ONLY public.formulas DROP CONSTRAINT formulas_pkey;
ALTER TABLE ONLY public.formula_nutrients DROP CONSTRAINT formula_nutrients_pkey;
ALTER TABLE ONLY public.formula_ingredients DROP CONSTRAINT formula_ingredients_pkey;
ALTER TABLE ONLY public.formula_ingredients_histories DROP CONSTRAINT formula_ingredients_histories_pkey;
ALTER TABLE ONLY public.ar_internal_metadata DROP CONSTRAINT ar_internal_metadata_pkey;
ALTER TABLE public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.premix_ingredients ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.nutrients ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.ingredients ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.ingredient_compositions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.formulas ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.formula_nutrients ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.formula_ingredients_histories ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.formula_ingredients ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.users_id_seq;
DROP TABLE public.users;
DROP TABLE public.schema_migrations;
DROP SEQUENCE public.premix_ingredients_id_seq;
DROP TABLE public.premix_ingredients;
DROP SEQUENCE public.nutrients_id_seq;
DROP TABLE public.nutrients;
DROP SEQUENCE public.ingredients_id_seq;
DROP TABLE public.ingredients;
DROP SEQUENCE public.ingredient_compositions_id_seq;
DROP TABLE public.ingredient_compositions;
DROP SEQUENCE public.formulas_id_seq;
DROP TABLE public.formulas;
DROP SEQUENCE public.formula_nutrients_id_seq;
DROP TABLE public.formula_nutrients;
DROP SEQUENCE public.formula_ingredients_id_seq;
DROP SEQUENCE public.formula_ingredients_histories_id_seq;
DROP TABLE public.formula_ingredients_histories;
DROP TABLE public.formula_ingredients;
DROP TABLE public.ar_internal_metadata;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: ar_internal_metadata; Type: TABLE; Schema: public; Owner: least_cost_feed
--

CREATE TABLE ar_internal_metadata (
    key character varying NOT NULL,
    value character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE ar_internal_metadata OWNER TO least_cost_feed;

--
-- Name: formula_ingredients; Type: TABLE; Schema: public; Owner: least_cost_feed
--

CREATE TABLE formula_ingredients (
    id integer NOT NULL,
    formula_id integer NOT NULL,
    ingredient_id integer NOT NULL,
    max double precision,
    min double precision,
    actual double precision DEFAULT 0.0 NOT NULL,
    weight double precision,
    shadow double precision DEFAULT 0.0 NOT NULL,
    use boolean DEFAULT true NOT NULL
);


ALTER TABLE formula_ingredients OWNER TO least_cost_feed;

--
-- Name: formula_ingredients_histories; Type: TABLE; Schema: public; Owner: least_cost_feed
--

CREATE TABLE formula_ingredients_histories (
    id bigint NOT NULL,
    formula_id bigint NOT NULL,
    ingredient_id bigint NOT NULL,
    actual numeric(12,6) DEFAULT 0 NOT NULL,
    use boolean DEFAULT true NOT NULL,
    logged_at character varying NOT NULL
);


ALTER TABLE formula_ingredients_histories OWNER TO least_cost_feed;

--
-- Name: formula_ingredients_histories_id_seq; Type: SEQUENCE; Schema: public; Owner: least_cost_feed
--

CREATE SEQUENCE formula_ingredients_histories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE formula_ingredients_histories_id_seq OWNER TO least_cost_feed;

--
-- Name: formula_ingredients_histories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: least_cost_feed
--

ALTER SEQUENCE formula_ingredients_histories_id_seq OWNED BY formula_ingredients_histories.id;


--
-- Name: formula_ingredients_id_seq; Type: SEQUENCE; Schema: public; Owner: least_cost_feed
--

CREATE SEQUENCE formula_ingredients_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE formula_ingredients_id_seq OWNER TO least_cost_feed;

--
-- Name: formula_ingredients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: least_cost_feed
--

ALTER SEQUENCE formula_ingredients_id_seq OWNED BY formula_ingredients.id;


--
-- Name: formula_nutrients; Type: TABLE; Schema: public; Owner: least_cost_feed
--

CREATE TABLE formula_nutrients (
    id integer NOT NULL,
    formula_id integer NOT NULL,
    nutrient_id integer NOT NULL,
    max double precision,
    min double precision,
    actual double precision DEFAULT 0.0 NOT NULL,
    use boolean DEFAULT true NOT NULL
);


ALTER TABLE formula_nutrients OWNER TO least_cost_feed;

--
-- Name: formula_nutrients_id_seq; Type: SEQUENCE; Schema: public; Owner: least_cost_feed
--

CREATE SEQUENCE formula_nutrients_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE formula_nutrients_id_seq OWNER TO least_cost_feed;

--
-- Name: formula_nutrients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: least_cost_feed
--

ALTER SEQUENCE formula_nutrients_id_seq OWNED BY formula_nutrients.id;


--
-- Name: formulas; Type: TABLE; Schema: public; Owner: least_cost_feed
--

CREATE TABLE formulas (
    id integer NOT NULL,
    user_id integer NOT NULL,
    name character varying(255) NOT NULL,
    batch_size double precision DEFAULT 0.0 NOT NULL,
    cost double precision DEFAULT 0.0 NOT NULL,
    note text,
    lock_version integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    target_bag_weight double precision DEFAULT 1,
    bags_of_premix integer DEFAULT 1,
    usage_bags integer DEFAULT 1,
    usage_per_day integer DEFAULT 0
);


ALTER TABLE formulas OWNER TO least_cost_feed;

--
-- Name: formulas_id_seq; Type: SEQUENCE; Schema: public; Owner: least_cost_feed
--

CREATE SEQUENCE formulas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE formulas_id_seq OWNER TO least_cost_feed;

--
-- Name: formulas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: least_cost_feed
--

ALTER SEQUENCE formulas_id_seq OWNED BY formulas.id;


--
-- Name: ingredient_compositions; Type: TABLE; Schema: public; Owner: least_cost_feed
--

CREATE TABLE ingredient_compositions (
    id integer NOT NULL,
    ingredient_id integer NOT NULL,
    nutrient_id integer NOT NULL,
    value double precision DEFAULT 0.0 NOT NULL
);


ALTER TABLE ingredient_compositions OWNER TO least_cost_feed;

--
-- Name: ingredient_compositions_id_seq; Type: SEQUENCE; Schema: public; Owner: least_cost_feed
--

CREATE SEQUENCE ingredient_compositions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ingredient_compositions_id_seq OWNER TO least_cost_feed;

--
-- Name: ingredient_compositions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: least_cost_feed
--

ALTER SEQUENCE ingredient_compositions_id_seq OWNED BY ingredient_compositions.id;


--
-- Name: ingredients; Type: TABLE; Schema: public; Owner: least_cost_feed
--

CREATE TABLE ingredients (
    id integer NOT NULL,
    user_id integer NOT NULL,
    name character varying(255) NOT NULL,
    package_weight double precision DEFAULT 0.1,
    cost double precision DEFAULT 0.0 NOT NULL,
    status character varying(255) DEFAULT 'using'::character varying NOT NULL,
    category character varying(255) DEFAULT 'private'::character varying NOT NULL,
    note text,
    lock_version integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE ingredients OWNER TO least_cost_feed;

--
-- Name: ingredients_id_seq; Type: SEQUENCE; Schema: public; Owner: least_cost_feed
--

CREATE SEQUENCE ingredients_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ingredients_id_seq OWNER TO least_cost_feed;

--
-- Name: ingredients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: least_cost_feed
--

ALTER SEQUENCE ingredients_id_seq OWNED BY ingredients.id;


--
-- Name: nutrients; Type: TABLE; Schema: public; Owner: least_cost_feed
--

CREATE TABLE nutrients (
    id integer NOT NULL,
    user_id integer NOT NULL,
    name character varying(255) NOT NULL,
    unit character varying(255) NOT NULL,
    note text,
    category character varying(255) DEFAULT 'private'::character varying NOT NULL,
    lock_version integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE nutrients OWNER TO least_cost_feed;

--
-- Name: nutrients_id_seq; Type: SEQUENCE; Schema: public; Owner: least_cost_feed
--

CREATE SEQUENCE nutrients_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE nutrients_id_seq OWNER TO least_cost_feed;

--
-- Name: nutrients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: least_cost_feed
--

ALTER SEQUENCE nutrients_id_seq OWNED BY nutrients.id;


--
-- Name: premix_ingredients; Type: TABLE; Schema: public; Owner: least_cost_feed
--

CREATE TABLE premix_ingredients (
    id integer NOT NULL,
    formula_id integer NOT NULL,
    ingredient_id integer NOT NULL,
    actual_usage double precision,
    premix_usage double precision
);


ALTER TABLE premix_ingredients OWNER TO least_cost_feed;

--
-- Name: premix_ingredients_id_seq; Type: SEQUENCE; Schema: public; Owner: least_cost_feed
--

CREATE SEQUENCE premix_ingredients_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE premix_ingredients_id_seq OWNER TO least_cost_feed;

--
-- Name: premix_ingredients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: least_cost_feed
--

ALTER SEQUENCE premix_ingredients_id_seq OWNED BY premix_ingredients.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: least_cost_feed
--

CREATE TABLE schema_migrations (
    version character varying(255) NOT NULL
);


ALTER TABLE schema_migrations OWNER TO least_cost_feed;

--
-- Name: users; Type: TABLE; Schema: public; Owner: least_cost_feed
--

CREATE TABLE users (
    id integer NOT NULL,
    username character varying(255) NOT NULL,
    email character varying(255),
    name character varying(255),
    password_digest character varying(255) NOT NULL,
    status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    is_admin boolean DEFAULT false NOT NULL,
    country character varying(255) DEFAULT 'Malaysia'::character varying NOT NULL,
    time_zone character varying(255) DEFAULT 'Kuala Lumpur'::character varying NOT NULL,
    weight_unit character varying(255) DEFAULT 'KG'::character varying NOT NULL,
    lock_version integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    last_login_at timestamp without time zone
);


ALTER TABLE users OWNER TO least_cost_feed;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: least_cost_feed
--

CREATE SEQUENCE users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE users_id_seq OWNER TO least_cost_feed;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: least_cost_feed
--

ALTER SEQUENCE users_id_seq OWNED BY users.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: least_cost_feed
--

ALTER TABLE ONLY formula_ingredients ALTER COLUMN id SET DEFAULT nextval('formula_ingredients_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: least_cost_feed
--

ALTER TABLE ONLY formula_ingredients_histories ALTER COLUMN id SET DEFAULT nextval('formula_ingredients_histories_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: least_cost_feed
--

ALTER TABLE ONLY formula_nutrients ALTER COLUMN id SET DEFAULT nextval('formula_nutrients_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: least_cost_feed
--

ALTER TABLE ONLY formulas ALTER COLUMN id SET DEFAULT nextval('formulas_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: least_cost_feed
--

ALTER TABLE ONLY ingredient_compositions ALTER COLUMN id SET DEFAULT nextval('ingredient_compositions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: least_cost_feed
--

ALTER TABLE ONLY ingredients ALTER COLUMN id SET DEFAULT nextval('ingredients_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: least_cost_feed
--

ALTER TABLE ONLY nutrients ALTER COLUMN id SET DEFAULT nextval('nutrients_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: least_cost_feed
--

ALTER TABLE ONLY premix_ingredients ALTER COLUMN id SET DEFAULT nextval('premix_ingredients_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: least_cost_feed
--

ALTER TABLE ONLY users ALTER COLUMN id SET DEFAULT nextval('users_id_seq'::regclass);


--
-- Data for Name: ar_internal_metadata; Type: TABLE DATA; Schema: public; Owner: least_cost_feed
--

COPY ar_internal_metadata (key, value, created_at, updated_at) FROM stdin;
\.
COPY ar_internal_metadata (key, value, created_at, updated_at) FROM '$$PATH$$/2278.dat';

--
-- Data for Name: formula_ingredients; Type: TABLE DATA; Schema: public; Owner: least_cost_feed
--

COPY formula_ingredients (id, formula_id, ingredient_id, max, min, actual, weight, shadow, use) FROM stdin;
\.
COPY formula_ingredients (id, formula_id, ingredient_id, max, min, actual, weight, shadow, use) FROM '$$PATH$$/2261.dat';

--
-- Data for Name: formula_ingredients_histories; Type: TABLE DATA; Schema: public; Owner: least_cost_feed
--

COPY formula_ingredients_histories (id, formula_id, ingredient_id, actual, use, logged_at) FROM stdin;
\.
COPY formula_ingredients_histories (id, formula_id, ingredient_id, actual, use, logged_at) FROM '$$PATH$$/2280.dat';

--
-- Name: formula_ingredients_histories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: least_cost_feed
--

SELECT pg_catalog.setval('formula_ingredients_histories_id_seq', 1049, true);


--
-- Name: formula_ingredients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: least_cost_feed
--

SELECT pg_catalog.setval('formula_ingredients_id_seq', 8481, true);


--
-- Data for Name: formula_nutrients; Type: TABLE DATA; Schema: public; Owner: least_cost_feed
--

COPY formula_nutrients (id, formula_id, nutrient_id, max, min, actual, use) FROM stdin;
\.
COPY formula_nutrients (id, formula_id, nutrient_id, max, min, actual, use) FROM '$$PATH$$/2263.dat';

--
-- Name: formula_nutrients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: least_cost_feed
--

SELECT pg_catalog.setval('formula_nutrients_id_seq', 8926, true);


--
-- Data for Name: formulas; Type: TABLE DATA; Schema: public; Owner: least_cost_feed
--

COPY formulas (id, user_id, name, batch_size, cost, note, lock_version, created_at, updated_at, target_bag_weight, bags_of_premix, usage_bags, usage_per_day) FROM stdin;
\.
COPY formulas (id, user_id, name, batch_size, cost, note, lock_version, created_at, updated_at, target_bag_weight, bags_of_premix, usage_bags, usage_per_day) FROM '$$PATH$$/2265.dat';

--
-- Name: formulas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: least_cost_feed
--

SELECT pg_catalog.setval('formulas_id_seq', 590, true);


--
-- Data for Name: ingredient_compositions; Type: TABLE DATA; Schema: public; Owner: least_cost_feed
--

COPY ingredient_compositions (id, ingredient_id, nutrient_id, value) FROM stdin;
\.
COPY ingredient_compositions (id, ingredient_id, nutrient_id, value) FROM '$$PATH$$/2267.dat';

--
-- Name: ingredient_compositions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: least_cost_feed
--

SELECT pg_catalog.setval('ingredient_compositions_id_seq', 212674, true);


--
-- Data for Name: ingredients; Type: TABLE DATA; Schema: public; Owner: least_cost_feed
--

COPY ingredients (id, user_id, name, package_weight, cost, status, category, note, lock_version, created_at, updated_at) FROM stdin;
\.
COPY ingredients (id, user_id, name, package_weight, cost, status, category, note, lock_version, created_at, updated_at) FROM '$$PATH$$/2269.dat';

--
-- Name: ingredients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: least_cost_feed
--

SELECT pg_catalog.setval('ingredients_id_seq', 29883, true);


--
-- Data for Name: nutrients; Type: TABLE DATA; Schema: public; Owner: least_cost_feed
--

COPY nutrients (id, user_id, name, unit, note, category, lock_version, created_at, updated_at) FROM stdin;
\.
COPY nutrients (id, user_id, name, unit, note, category, lock_version, created_at, updated_at) FROM '$$PATH$$/2271.dat';

--
-- Name: nutrients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: least_cost_feed
--

SELECT pg_catalog.setval('nutrients_id_seq', 49840, true);


--
-- Data for Name: premix_ingredients; Type: TABLE DATA; Schema: public; Owner: least_cost_feed
--

COPY premix_ingredients (id, formula_id, ingredient_id, actual_usage, premix_usage) FROM stdin;
\.
COPY premix_ingredients (id, formula_id, ingredient_id, actual_usage, premix_usage) FROM '$$PATH$$/2273.dat';

--
-- Name: premix_ingredients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: least_cost_feed
--

SELECT pg_catalog.setval('premix_ingredients_id_seq', 21415, true);


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: least_cost_feed
--

COPY schema_migrations (version) FROM stdin;
\.
COPY schema_migrations (version) FROM '$$PATH$$/2275.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: least_cost_feed
--

COPY users (id, username, email, name, password_digest, status, is_admin, country, time_zone, weight_unit, lock_version, created_at, updated_at, last_login_at) FROM stdin;
\.
COPY users (id, username, email, name, password_digest, status, is_admin, country, time_zone, weight_unit, lock_version, created_at, updated_at, last_login_at) FROM '$$PATH$$/2276.dat';

--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: least_cost_feed
--

SELECT pg_catalog.setval('users_id_seq', 981, true);


--
-- Name: ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: least_cost_feed
--

ALTER TABLE ONLY ar_internal_metadata
    ADD CONSTRAINT ar_internal_metadata_pkey PRIMARY KEY (key);


--
-- Name: formula_ingredients_histories_pkey; Type: CONSTRAINT; Schema: public; Owner: least_cost_feed
--

ALTER TABLE ONLY formula_ingredients_histories
    ADD CONSTRAINT formula_ingredients_histories_pkey PRIMARY KEY (id);


--
-- Name: formula_ingredients_pkey; Type: CONSTRAINT; Schema: public; Owner: least_cost_feed
--

ALTER TABLE ONLY formula_ingredients
    ADD CONSTRAINT formula_ingredients_pkey PRIMARY KEY (id);


--
-- Name: formula_nutrients_pkey; Type: CONSTRAINT; Schema: public; Owner: least_cost_feed
--

ALTER TABLE ONLY formula_nutrients
    ADD CONSTRAINT formula_nutrients_pkey PRIMARY KEY (id);


--
-- Name: formulas_pkey; Type: CONSTRAINT; Schema: public; Owner: least_cost_feed
--

ALTER TABLE ONLY formulas
    ADD CONSTRAINT formulas_pkey PRIMARY KEY (id);


--
-- Name: ingredient_compositions_pkey; Type: CONSTRAINT; Schema: public; Owner: least_cost_feed
--

ALTER TABLE ONLY ingredient_compositions
    ADD CONSTRAINT ingredient_compositions_pkey PRIMARY KEY (id);


--
-- Name: ingredients_pkey; Type: CONSTRAINT; Schema: public; Owner: least_cost_feed
--

ALTER TABLE ONLY ingredients
    ADD CONSTRAINT ingredients_pkey PRIMARY KEY (id);


--
-- Name: nutrients_pkey; Type: CONSTRAINT; Schema: public; Owner: least_cost_feed
--

ALTER TABLE ONLY nutrients
    ADD CONSTRAINT nutrients_pkey PRIMARY KEY (id);


--
-- Name: premix_ingredients_pkey; Type: CONSTRAINT; Schema: public; Owner: least_cost_feed
--

ALTER TABLE ONLY premix_ingredients
    ADD CONSTRAINT premix_ingredients_pkey PRIMARY KEY (id);


--
-- Name: users_pkey; Type: CONSTRAINT; Schema: public; Owner: least_cost_feed
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: by_ing_id_for_id_log_at; Type: INDEX; Schema: public; Owner: least_cost_feed
--

CREATE UNIQUE INDEX by_ing_id_for_id_log_at ON formula_ingredients_histories USING btree (ingredient_id, formula_id, logged_at);


--
-- Name: index_formula_ingredients_histories_on_formula_id; Type: INDEX; Schema: public; Owner: least_cost_feed
--

CREATE INDEX index_formula_ingredients_histories_on_formula_id ON formula_ingredients_histories USING btree (formula_id);


--
-- Name: index_formula_ingredients_histories_on_ingredient_id; Type: INDEX; Schema: public; Owner: least_cost_feed
--

CREATE INDEX index_formula_ingredients_histories_on_ingredient_id ON formula_ingredients_histories USING btree (ingredient_id);


--
-- Name: index_formula_ingredients_on_ingredient_id_and_formula_id; Type: INDEX; Schema: public; Owner: least_cost_feed
--

CREATE UNIQUE INDEX index_formula_ingredients_on_ingredient_id_and_formula_id ON formula_ingredients USING btree (ingredient_id, formula_id);


--
-- Name: index_formula_nutrients_on_nutrient_id_and_formula_id; Type: INDEX; Schema: public; Owner: least_cost_feed
--

CREATE UNIQUE INDEX index_formula_nutrients_on_nutrient_id_and_formula_id ON formula_nutrients USING btree (nutrient_id, formula_id);


--
-- Name: index_ingredient_compositions_on_ingredient_id_and_nutrient_id; Type: INDEX; Schema: public; Owner: least_cost_feed
--

CREATE UNIQUE INDEX index_ingredient_compositions_on_ingredient_id_and_nutrient_id ON ingredient_compositions USING btree (ingredient_id, nutrient_id);


--
-- Name: index_ingredients_on_user_id_and_name; Type: INDEX; Schema: public; Owner: least_cost_feed
--

CREATE UNIQUE INDEX index_ingredients_on_user_id_and_name ON ingredients USING btree (user_id, name);


--
-- Name: index_nutrients_on_user_id_and_name; Type: INDEX; Schema: public; Owner: least_cost_feed
--

CREATE UNIQUE INDEX index_nutrients_on_user_id_and_name ON nutrients USING btree (user_id, name);


--
-- Name: index_premix_ingredients_on_ingredient_id_and_formula_id; Type: INDEX; Schema: public; Owner: least_cost_feed
--

CREATE UNIQUE INDEX index_premix_ingredients_on_ingredient_id_and_formula_id ON premix_ingredients USING btree (ingredient_id, formula_id);


--
-- Name: index_users_on_username; Type: INDEX; Schema: public; Owner: least_cost_feed
--

CREATE UNIQUE INDEX index_users_on_username ON users USING btree (username);


--
-- Name: unique_schema_migrations; Type: INDEX; Schema: public; Owner: least_cost_feed
--

CREATE UNIQUE INDEX unique_schema_migrations ON schema_migrations USING btree (version);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

